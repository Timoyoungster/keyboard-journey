# Testing and Debugging

## Testing

[Moved here](faq_misc.md#testing)

## Debugging :id=debugging

[Moved here](faq_debug.md#debugging)
